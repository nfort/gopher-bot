package main

import (
	"testing"
)

func TestGreeting(t *testing.T) {
	expect := "Hello World"
	actual := Greeting()

	if actual != expect {
		t.Errorf("expect: %q, got: %q", expect, actual)
	}
}
